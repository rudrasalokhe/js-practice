const fs = require("fs");
function afterFileRead(err, contents){
    
}